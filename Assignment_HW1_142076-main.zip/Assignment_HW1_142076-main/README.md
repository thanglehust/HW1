## Assignment 1

Here is my work for assignment 1.

**Đỗ Đoàn Khuê_20192945_N10_HW1** 
